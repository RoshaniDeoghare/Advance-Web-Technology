function comparator(a,b)
{
  if(a.radius<b.radius)
    {
      return -1;
    }
  else if(a.radius>b.radius)
    {
      return 1; 
    }
  else
    {
      return 0;
    }
}