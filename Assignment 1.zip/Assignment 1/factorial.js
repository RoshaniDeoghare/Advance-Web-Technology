function factorial(num)
{
 var fact = 1;
  for(var x=num;x > 1;x--)
    {
      var fact = fact * x;
    }
  return fact;
};
