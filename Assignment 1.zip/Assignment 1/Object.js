var Employee = {
    id : 100,
    Name : "Deepika Singh",
    designation : "Project Manager",
    salary : 20000,
    Company:"TCS",
    Details : function()
    {
      return(this.Name + " is woking in "+ this.company + "as a" + this.designation);
    }
   };
  