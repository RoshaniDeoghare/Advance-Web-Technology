function add_all(arr)
{
  var sum = 0;
  for(var i in arr)
    {
      sum = sum + arr[i];
    }
	return sum;
};