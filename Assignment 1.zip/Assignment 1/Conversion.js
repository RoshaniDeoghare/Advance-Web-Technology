function toCelsius(f)
{
  var celsius = (5/9) * (f-32);
  return celsius ;
}



function toFahrenheit(c)
{
  var Fahrenheit= ((9*c)/5) + 32 ;
return Fahrenheit;
}

