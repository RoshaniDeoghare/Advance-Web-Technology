
function is_integer(x)
{ 
  
  if(isNaN(x))
    {
         console.log("The entered value is not an integer");
    }
  else
    {
         console.log("The entered value is an integer");
    }
};
