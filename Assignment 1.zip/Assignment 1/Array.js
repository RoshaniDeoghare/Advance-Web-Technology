

function array(Days)
{
    for(var i in Days)
    {
        var result = console.log("Days "+ i +" : "+ Days[i]);
    }
    
}
