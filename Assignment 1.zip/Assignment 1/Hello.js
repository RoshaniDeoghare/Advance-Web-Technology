function Hello()
{
    console.log("Hello World");
    window.alert("Welcome to JavaScript");
}